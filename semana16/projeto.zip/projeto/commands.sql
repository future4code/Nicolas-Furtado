-- criando uma nova tabela de usuarios
CREATE TABLE TodoListUser (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NULL,
  nickname VARCHAR(255) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL
);

-- populando a tabela de users
INSERT INTO
  TodoListUser (name, nickname, email)
VALUES
  (
    "Janis Costadelli",
    "Janisu",
    "janis@janis.com"
  ),
  (
    "Nicolas Alexandre",
    "parkournick",
    "nicolas@nicolas.com"
  );

-- criando tabela de tarefa
CREATE TABLE TodoListTask (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  status VARCHAR(255) NOT NULL DEFAULT "to_do",
  limit_date DATE NOT NULL,
  creator_user_id INT NOT NULL,
  FOREIGN KEY (creator_user_id) REFERENCES TodoListUser(id)
);

